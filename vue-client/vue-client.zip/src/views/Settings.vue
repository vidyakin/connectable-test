<template>

  <div class="about">
    <div class="container-fluid">
      <div class="row no-gutters">
        <div class="col-sm-12">
          <h1>Настройки</h1>
        </div>
        <div class="col-sm-12 content-wrap">
          <h4>Нотификации</h4>
          <ul>
            <li>
              <label for="addUser">
                <input type="checkbox" id="addUser" name="addUser" />
                При добавлении юзера
              </label>
            </li>
            <li>
              <label for="publications">
                <input type="checkbox" id="publications" name="publications" />
                При публикации в разделе компания, в группах, в которых состоит юзер, у
                пользователей, на которых он подписан
              </label>
            </li>
            <li>
              <label for="eventComment">
                <input type="checkbox" id="eventComment" name="eventComment" />
                во всех публикациях и комментариях, где юзера тегнули через @
              </label>
            </li>
            <li>
              <label for="eventCalendar">
                <input type="checkbox" id="eventCalendar" name="eventCalendar" />
                при добавлении события в Календарь
              </label>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
<style lang="scss">
  .about {
    background-color: #f0f0f7;
    h1 {
      text-align: center;
    }
    .row {
      background: none;
    }
    .content-wrap {
      text-align: left;

      ul {
        list-style: none;
        padding: 0 0 0;
      }

    }
  }

</style>