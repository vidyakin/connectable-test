export const SEND_NEW_POST = 'SEND_NEW_POST';

export const GET_POSTS = 'GET_POSTS';
export const DELETE_POST = 'DELETE_POST';

export const SEND_LIKE = 'SEND_LIKE';
export const SEND_COMMENT = 'SEND_COMMENT';
export const REPOST = 'REPOST';
export const EDIT_POST = 'EDIT_POST';
