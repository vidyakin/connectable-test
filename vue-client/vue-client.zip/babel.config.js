module.exports = {
  presets: [
    "@babel/env",
    '@vue/app',
    
  ]
}
